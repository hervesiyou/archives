from enum import Enum


class RoleEnum(Enum):
    MEMBRE = "MEMBRE"
    SUPERADMIN = "SUPERADMIN"
    ADMIN = "ADMIN"
    LIBRAIRE = "LIBRAIRE"
    CLIENT = "CLIENT"
    # FAM_CHEF = "FAM_CHEF"
    # FAM_USER = "FAM_USER"
    # FAM_ADMIN = "FAM_ADMIN"
    # ASS_USER = "ASS_USER"
    # ASS_ADMIN = "ASS_ADMIN"
    # LIB_MANAGER = "LIB_MANAGER"
    # LIB_USER = "LIB_USER"


    @classmethod
    def choices(cls):
        return tuple((i.value, i.name) for i in cls)
